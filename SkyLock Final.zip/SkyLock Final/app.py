import os
import tempfile
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
import boto3
from cryptography.fernet import Fernet
from io import BytesIO

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'  
app.debug = True

def generate_key():
    """Generates a Fernet encryption key."""
    return Fernet.generate_key()

def encrypt_file(file):
    """Encrypts the content of the provided file."""
    key = generate_key()
    cipher = Fernet(key)
    file_content = file.read()
    encrypted_content = cipher.encrypt(file_content)
    return encrypted_content, key

def decrypt_file(file, key):
    """Decrypts the provided file using the provided key."""
    cipher = Fernet(key)
    encrypted_content = file.read()
    decrypted_content = cipher.decrypt(encrypted_content)
    return decrypted_content

@app.route('/')
def home():
    """Renders the home page."""
    return render_template('index.html')

@app.route('/redirect', methods=['POST'])
def redirect_to_login():
    cloud_platform = request.form['cloud_platform']

    if cloud_platform == 'aws':
        return redirect('https://aws.amazon.com/')
    elif cloud_platform == 'gcp':
        return redirect('https://cloud.google.com/')
    elif cloud_platform == 'azure':
        return redirect('https://azure.microsoft.com/')
    elif cloud_platform == 'dropbox':
        return redirect('https://www.dropbox.com/login')
    # Add more platforms as needed

    flash('Invalid cloud platform selected.')
    return redirect(url_for('home'))

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handles file uploads to AWS S3."""
    aws_access_key_id = request.form['aws_access_key_id']
    aws_secret_access_key = request.form['aws_secret_access_key']
    aws_bucket_name = request.form['aws_bucket_name']

    s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)
    file = request.files.get('file')

    if not file or file.filename == '':
        flash('No file selected for upload!')
        return redirect(request.url)

    try:
        s3.upload_fileobj(file, aws_bucket_name, file.filename)
        flash('File uploaded successfully!')
    except Exception as e:
        flash(f'File upload failed: {str(e)}')

    return redirect(url_for('home'))

@app.route('/encrypt', methods=['POST'])
def encrypt_file_route():
    """Encrypts the uploaded file and stores the encrypted content and key."""
    file = request.files.get('file')
    if not file:
        flash('No file selected for encryption!')
        return redirect(url_for('home'))

    # Encrypt the file content
    encrypted_content, key = encrypt_file(file)

    # Save encrypted content and key to temporary files
    temp_dir = tempfile.gettempdir()
    encrypted_file_path = os.path.join(temp_dir, f"encrypted_{file.filename}.bin")
    key_file_path = os.path.join(temp_dir, f"{file.filename}_key.bin")

    with open(encrypted_file_path, 'wb') as enc_file:
        enc_file.write(encrypted_content)
    
    with open(key_file_path, 'wb') as k_file:
        k_file.write(key)

    # Store paths in session
    session['encrypted_file_path'] = encrypted_file_path
    session['key_file_path'] = key_file_path
    session['file_name'] = file.filename

    flash('File encrypted successfully! You can download the encrypted file and key below.')
    return redirect(url_for('download_links'))

@app.route('/download_links')
def download_links():
    """Renders the download links page."""
    return render_template('download_links.html')

@app.route('/download/encrypted')
def download_encrypted_file():
    """Handles the download of the encrypted file."""
    encrypted_file_path = session.get('encrypted_file_path')
    file_name = session.get('file_name', 'encrypted_file')

    if not encrypted_file_path or not os.path.exists(encrypted_file_path):
        flash('No encrypted file available for download.')
        return redirect(url_for('home'))

    return send_file(
        encrypted_file_path,
        as_attachment=True,
        download_name=f"encrypted_{file_name}.bin",
        mimetype='application/octet-stream'
    )

@app.route('/download/key')
def download_key_file():
    """Handles the download of the encryption key."""
    key_file_path = session.get('key_file_path')
    file_name = session.get('file_name', 'key_file')

    if not key_file_path or not os.path.exists(key_file_path):
        flash('No key available for download.')
        return redirect(url_for('home'))

    return send_file(
        key_file_path,
        as_attachment=True,
        download_name=f"{file_name}_key.bin",
        mimetype='application/octet-stream'
    )

@app.route('/decrypt', methods=['POST'])
def decrypt_file_route():
    """Handles the decryption of the uploaded file."""
    key_file = request.files.get('key')
    file = request.files.get('file')

    if not file or not key_file:
        flash('File or key file not selected for decryption!')
        return redirect(url_for('home'))

    key_content = key_file.read()
    try:
        decrypted_content = decrypt_file(file, key_content)
    except Exception as e:
        flash(f'Decryption failed: {str(e)}')
        return redirect(url_for('home'))

    # Save decrypted content to a temporary file
    temp_dir = tempfile.gettempdir()
    decrypted_file_path = os.path.join(temp_dir, f"decrypted_{file.filename}")

    with open(decrypted_file_path, 'wb') as dec_file:
        dec_file.write(decrypted_content)

    # Store path in session for downloading
    session['decrypted_file_path'] = decrypted_file_path
    session['decrypted_file_name'] = f"decrypted_{file.filename}"

    flash('File decrypted successfully! You can download the decrypted file below.')
    return redirect(url_for('download_decrypted_file'))

@app.route('/download/decrypted')
def download_decrypted_file():
    """Handles the download of the decrypted file."""
    decrypted_file_path = session.get('decrypted_file_path')
    decrypted_file_name = session.get('decrypted_file_name', 'decrypted_file')

    if not decrypted_file_path or not os.path.exists(decrypted_file_path):
        flash('No decrypted file available for download.')
        return redirect(url_for('home'))

    return send_file(
        decrypted_file_path,
        as_attachment=True,
        download_name=decrypted_file_name,
        mimetype='application/octet-stream'
    )


if __name__ == '__main__':
    app.run(debug=True)
